# Mind1Train Apps — GitHub Pages

Static privacy-policy website. Upload the folders and files to the root of the `mind1trainapps.github.io` repository.

Each new app gets a separate directory under `privacy/`.
